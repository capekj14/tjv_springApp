package cz.cvut.fit.tjv.capekj14.semestral.project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SemestralProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
