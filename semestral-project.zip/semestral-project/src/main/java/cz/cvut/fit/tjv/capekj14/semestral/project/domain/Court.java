package cz.cvut.fit.tjv.capekj14.semestral.project.domain;

public class Court {

    public int number;
    public int id;

    public Court(int number, int id) {
        this.number = number;
        this.id = id;
   }

    public Court(){}

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

}
