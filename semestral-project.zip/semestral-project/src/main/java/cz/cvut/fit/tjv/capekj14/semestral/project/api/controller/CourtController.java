package cz.cvut.fit.tjv.capekj14.semestral.project.api.controller;

import org.springframework.web.bind.annotation.*;

@RestController
public class CourtController {

    @GetMapping("/courts")
    String getAll() {
        return "VSECHNY KURTY";
    }
    @GetMapping("/courts/{id}")
    String getOne(){
        return "KURT CISLO X";
    }

    @PutMapping("/courts/{id}")
    String update(){
        return "UPDATIM KURT CISLO X";
    }

    @DeleteMapping("/courts/{id}")
    void delete(){ return;}
    @PostMapping("/users")
    String add(){
        return "VKLADAM KURT CISLO X";
    }
}
