package cz.cvut.fit.tjv.capekj14.semestral.project.api.controller;

import java.util.Objects;

public class CourtDto {
    public int number;
    public int id;

    public CourtDto(int number, int id) {
        this.number = number;
        this.id = id;
    }

    @Override
    public String toString() {
        return "CourtDto{" +
                "number=" + number +
                ", id=" + id +
                '}';
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CourtDto courtDto = (CourtDto) o;
        return number == courtDto.number && id == courtDto.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(number, id);
    }
}
