package cz.cvut.fit.tjv.capekj14.semestral.project.api.controller;

import org.springframework.web.bind.annotation.*;

@RestController
public class TrainingController {
    @GetMapping("/trainings")
    String getAll() {
        return "VSECHNY TRENINKY";
    }
    @GetMapping("/trainings/{id}")
    String getOne(){
        return "TRENINK";
    }
    @PutMapping("/trainings/{id}")
    String update(){
        return "UPDATIM TRENINK";
    }
    @DeleteMapping("/trainings/{id}")
    void delete(){ return;}
    @PostMapping("/trainings")
    String add(){
        return "VKLADAM TRENINK";
    }

}
