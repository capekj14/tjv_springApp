package cz.cvut.fit.tjv.capekj14.semestral.project.api.controller;

import java.time.LocalDateTime;

public class TrainingDto {
    public int hours;
    public int id;
    public LocalDateTime start;

    public TrainingDto(int hours, int id, LocalDateTime start) {
        this.hours = hours;
        this.id = id;
        this.start = start;
    }

    public int getHours() {
        return hours;
    }

    public void setHours(int hours) {
        this.hours = hours;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public LocalDateTime getStart() {
        return start;
    }

    public void setStart(LocalDateTime start) {
        this.start = start;
    }

    @Override
    public String toString() {
        return "TrainingDto{" +
                "hours=" + hours +
                ", id=" + id +
                ", start=" + start +
                '}';
    }
}
