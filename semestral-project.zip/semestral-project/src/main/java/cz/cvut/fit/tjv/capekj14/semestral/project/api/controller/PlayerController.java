package cz.cvut.fit.tjv.capekj14.semestral.project.api.controller;

import org.springframework.web.bind.annotation.*;

@RestController
public class PlayerController {
    @GetMapping("/players")
    String getAll() {
        return "VSICHNI HRACI";
    }

    @GetMapping("/players/{id}")
    String getOne(){
        return "HRAC";
    }

    @PutMapping("/players/{id}")
    String update(){
        return "UPDATIM HRACE";
    }

    @DeleteMapping("/players/{id}")
    void delete(){
        return;
    }

    @PostMapping("/players")
    String add(){
        return "VKLADAM HRACE";
    }
}
